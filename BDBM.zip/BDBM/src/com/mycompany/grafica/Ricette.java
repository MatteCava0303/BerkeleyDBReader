
package com.mycompany.grafica;

import static com.sleepycat.persist.model.Relationship.MANY_TO_ONE;

import com.sleepycat.persist.model.Entity;
import com.sleepycat.persist.model.PrimaryKey;
import com.sleepycat.persist.model.SecondaryKey;

@Entity
public class Ricette {

    private String ingr2;
    private String ingr3;


    @PrimaryKey
    private String ingr1;
    @SecondaryKey(relate=MANY_TO_ONE)
    private String itemName;
    
 

    public void setSku(String data) {
        itemName = data;
    }
    public String getSku() {
        return itemName;
    }
    public void setIngr1(String data) {
       ingr1 = data;
    }

    public String getIngr1() {
        return ingr1;
    }
    public void setIngr2(String data) {
        ingr2 = data;
     }

     public String getIngr2() {
         return ingr2;
     }
     public void setIngr3(String data) {
         ingr3 = data;
      }

      public String getIngr3() {
          return ingr3;
      }

}
