package com.mycompany.grafica;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.List;

import com.sleepycat.je.Cursor;
import com.sleepycat.je.CursorConfig;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;
import com.sleepycat.je.Get;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;
import com.sleepycat.je.Transaction;
import com.sleepycat.je.TransactionConfig;
import com.sleepycat.persist.EntityCursor;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;

public class ExampleInventoryRead {

    public static String percorsoFile = "";
    public static File myDbEnvPath = new File(percorsoFile);
    public DataAccessor da;
    public static MyDbEnv myDbEnv = new MyDbEnv();
    Environment myDbEnvironment;
    Database myDBDB = null;
    OperationStatus c = null;
    private static String locateItem = null;
    public Enum<?> arrays[];
    public static void usage() {
        System.out.println("ExampleInventoryRead [-h <env directory>]"
                + "[-s <item to locate>]");
        System.exit(-1);
    }
    public static void main(String args[]) throws IOException {
        ExampleInventoryRead eir = new ExampleInventoryRead();
        try {
            eir.run(args);
        } catch (DatabaseException dbe) {
            System.err.println("ExampleInventoryRead: " + dbe.toString());
            dbe.printStackTrace();
        } finally {
            myDbEnv.close();
        }
        System.out.println("All done.");
    }
    public void run(String args[])
            throws DatabaseException, IOException {
        parseArgs(args);
        myDbEnv.setup(myDbEnvPath,false);
        da = new DataAccessor(myDbEnv.getEntityStore());
        if (locateItem != null) {
            showItem();
        } else {
            showAllInventory();
        }
    }
    public void setPercorsoFile(String a) {//METODO PER SELEZIONARE UN PERCORSO DI UN DATABASE
        this.percorsoFile = a;
    }
    public void showItem() throws DatabaseException {

        EntityCursor<Inventory> items
                = da.inventoryByName.subIndex(locateItem).entities();
        try {
            for (Inventory item : items) {
                displayInventoryRecord(item);
            }
        } finally {
            items.close();
        }
    }
    public String[][] getValue(String a) throws FileNotFoundException {//METODO PER LEGGERE LE COPPIE CHIAVI VALORI PRESENTI IN UNA TABELLA
        DatabaseConfig dbc = new DatabaseConfig();
        String[][] values = null;

        dbc.setReadOnly(true);
        dbc.setSortedDuplicates(false);
        myDBDB = myDbEnvironment.openDatabase(null, a, dbc);
        int ad = (int) myDBDB.count();
        if (ad == 0) {
            return values;
        } else {
            //DEBUG System.out.println("------------------>" + ad);
            values = new String[ad][2];
            CursorConfig cf = new CursorConfig();
            cf.setReadCommitted(true);
            Cursor cursor = myDBDB.openCursor(null, cf);
            DatabaseEntry key = new DatabaseEntry();
            DatabaseEntry value = new DatabaseEntry();
            cursor.getFirst(key, value, null);
            int numero_chiavi_valore = (int) myDBDB.count();
            for (int i = 0; i < numero_chiavi_valore; i++) {
                cursor.getNext(key, value, null);
                System.out.println("COPPIA NUMERO: "+i+ " CHIAVE: " + key + " VALORE: " + value);//DEBUG 
                values[i][0] = key.toString();
                values[i][1] = value.toString();
            }
        }
        return values;//RETURNA UN OGGETTO DI OGGETTO CHE CONTERRA LE COPPIE CHIAVI VALORI
    }
    public ArrayList<String> getAllDatabaseTable(String a) {//METODO PER LEGGERE TUTTE LE TABELLE PRESENTI IN UN DATABASE
        myDbEnvironment = new Environment(new File(a), null);
        ArrayList<String> myDB = (ArrayList<String>) myDbEnvironment.getDatabaseNames();

        for (String gino : myDB) {
            //System.out.println(gino+";");     
        }
        return myDB;//TI RETURNA UN ARRAYLIST DI STRINGHE
    }
    @SuppressWarnings("resource")
    public void showAllInventory()
            throws DatabaseException, IOException {
        EntityCursor<Inventory> items
                = da.inventoryBySku.entities();

        try {

            for (Inventory item : items) {
                displayInventoryRecord(item);
            }
        } catch (Error ex) {
            ex.printStackTrace();
        } finally {

            items.close();
        }
    }
    public OperationStatus[] valuess(OperationStatus c2) {

        for (OperationStatus ad : OperationStatus.values()) {
            System.out.println("DENTRO VALUESS " + ad);

        }
        return null;
    }
    public void displayInventoryRecord(Inventory theInventory)
            throws DatabaseException {
        System.out.println(theInventory.getSku() + ":");
        System.out.println("\t " + theInventory.getItemName());
        System.out.println("\t " + theInventory.getCategory());
        System.out.println("\t " + theInventory.getAllergeni());
        Ricette theRicette = da.ricetteByName.get(theInventory.getItemName());
        assert theRicette != null;
        System.out.println("\t\t"
                + theRicette);
        System.out.println("\t\t"
                + theRicette.getSku());
        System.out.println("\t\t1� ingreidente: "
                + theRicette.getIngr1());
        System.out.println("\t\t2� ingreidente: "
                + theRicette.getIngr2());
        System.out.println("\t\t3� ingreidente: "
                + theRicette.getIngr3());
        System.out.println("\t " + theInventory.getVendor());
        System.out.println("\t\tNumber in stock: "
                + theInventory.getVendorInventory());
        System.out.println("\t\tPrice per unit:  "
                + theInventory.getVendorPrice());
        System.out.println("\t\tContact: ");
        Vendor theVendor= da.vendorByName.get(theInventory.getVendor());
        assert theVendor != null;
        System.out.println("\t\t " + theVendor.getAddress());
        System.out.println("\t\t " + theVendor.getCity() + ", "
                + theVendor.getState() + " " + theVendor.getZipcode());
        System.out.println("\t\t Business Phone: "
                + theVendor.getBusinessPhoneNumber());
        System.out.println("\t\t Sales Rep: "
                + theVendor.getRepName());
        System.out.println("\t\t Sedi: "
                + theVendor.getSedi());
        System.out.println("\t\t            "
                + theVendor.getRepPhoneNumber());
    }
    public static void parseArgs(String args[]) {
        for (int i = 0; i < args.length; ++i) {
            if (args[i].startsWith("-")) {
                switch (args[i].charAt(1)) {
                    case 'h':
                        myDbEnvPath = new File(args[++i]);
                        break;
                    case 's':
                        locateItem = args[++i];
                        break;
                    default:
                        usage();
                }
            }
        }
    }

}
